extends Node2D

@export var triangle_count: int = 5
@export var base_width: float = 80.0
@export var base_height: float = 200.0   # height of the first (biggest) triangle
@export var spacing: float = 120.0       # horizontal distance between triangles
@export var jump_duration: float = 3.0   # was 0.6 — much slower for testing
@export var stagger_delay: float = 1.0   # was 0.15 — more spread out

var triangles: Array[Polygon2D] = []

var _initialized: bool = false

func _ready() -> void:
	if _initialized:
		push_warning("Domain._ready() called again — duplicate instance detected!")
		return
	_initialized = true

	await get_tree().create_timer(1).timeout
	_create_triangles()
	print("Creating triangles done, starting jump_all")
	jump_all()

func _create_triangles() -> void:
	for i in range(triangle_count):
		var t: float = float(i) / float(triangle_count - 1) # 0.0 -> 1.0 across the line

		# Jump height: 100% for first, 25% for last (a 75% smaller jump)
		var jump_percent: float = lerp(1.0, 0.25, t)

		# Height growth on jump: 10% for first, 0% for last
		var growth_percent: float = lerp(0.10, 0.0, t)

		var tri := Polygon2D.new()
		tri.name = "Triangle%d" % i
		tri.position = Vector2(i * spacing, 0)
		tri.set_meta("jump_percent", jump_percent)
		tri.set_meta("growth_percent", growth_percent)

		_draw_triangle(tri, base_width, base_height)
		add_child(tri)
		triangles.append(tri)

func _draw_triangle(tri: Polygon2D, w: float, h: float) -> void:
	# Isosceles triangle, apex up, baseline sits at tri's local y = 0
	tri.polygon = PackedVector2Array([
		Vector2(-w / 2.0, 0),
		Vector2(w / 2.0, 0),
		Vector2(0, -h)
	])

func jump_all() -> void:
	for i in range(triangles.size()):
		var tri: Polygon2D = triangles[i]
		get_tree().create_timer(i * stagger_delay).timeout.connect(_jump_one.bind(tri))

func _jump_one(tri: Polygon2D) -> void:
	var jump_percent: float = tri.get_meta("jump_percent")
	var growth_percent: float = tri.get_meta("growth_percent")
	var jump_distance: float = base_height * jump_percent

	var tween := create_tween()
	tween.set_parallel(true)
	tween.tween_property(tri, "position:y", -jump_distance, jump_duration)\
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	print("first")
	#tween.tween_method(func(y): print(tri.name, " y = ", y), 0.0, -jump_distance, jump_duration)

	if growth_percent > 0.0:
		tween.tween_property(tri, "scale:y", 1.0 + growth_percent, jump_duration)\
			.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)

	await get_tree().create_timer(jump_duration).timeout
	var tween2 := create_tween()
	tween2.tween_property(tri, "position:y", 0.0, jump_duration)\
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	print("second")
	if growth_percent > 0.0:
		tween2.tween_property(tri, "scale:y", 1.0, jump_duration)\
			.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
			
func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_accept"): # Enter key, for quick testing
		jump_all()
	
#func _process(_delta: float) -> void:
	#if triangles.size() > 0:
		#print("Frame check T0 y = ", triangles[0].position.y)
